from flask import Flask, render_template, request
import pickle
import numpy as np
import os

app = Flask(__name__)

# Base directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Load model/scaler function
def load_file(filename):
    return pickle.load(open(os.path.join(BASE_DIR, "models", filename), "rb"))

# ---------------- LOAD MODELS + SCALERS ---------------- #

diabetes_model  = load_file("diabetes_model.pkl")
diabetes_scaler = load_file("diabetes_scaler.pkl")

heart_model     = load_file("heart_model.pkl")
heart_scaler    = load_file("heart_scaler.pkl")

liver_model     = load_file("liver_model.pkl")
liver_scaler    = load_file("liver_scaler.pkl")

kidney_model    = load_file("kidney_model.pkl")
kidney_scaler   = load_file("kidney_scaler.pkl")

lung_model      = load_file("lung_model.pkl")
lung_scaler     = load_file("lung_scaler.pkl")

# ---------------- ROUTES ---------------- #

@app.route("/")
def home():
    return render_template("index.html")


@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")


@app.route("/predict", methods=["POST"])
def predict():
    try:
        # ----------- GET INPUT ----------- #
        age         = float(request.form["age"])
        glucose     = float(request.form.get("glucose", 0))
        bp          = float(request.form.get("bp", 0))
        bmi         = float(request.form.get("bmi", 0))
        cholesterol = float(request.form.get("cholesterol", 0))
        heart_rate  = float(request.form.get("heart_rate", 0))
        bilirubin   = float(request.form.get("bilirubin", 0))
        albumin     = float(request.form.get("albumin", 0))
        urea        = float(request.form.get("urea", 0))
        creatinine  = float(request.form.get("creatinine", 0))
        smoking     = float(request.form.get("smoking", 0))
        chest_pain  = float(request.form.get("chest_pain", 0))
        fatigue     = float(request.form.get("fatigue", 0))

        # ----------- PREPARE INPUTS ----------- #

        diabetes_input = np.array([[glucose, bp, bmi, age]])
        diabetes_input = diabetes_scaler.transform(diabetes_input)

        heart_input = np.array([[age, cholesterol, bp, heart_rate]])
        heart_input = heart_scaler.transform(heart_input)

        liver_input = np.array([[age, bilirubin, albumin]])
        liver_input = liver_scaler.transform(liver_input)

        kidney_input = np.array([[age, bp, urea, creatinine]])
        kidney_input = kidney_scaler.transform(kidney_input)

        lung_input = np.array([[age, smoking, chest_pain, fatigue]])
        lung_input = lung_scaler.transform(lung_input)

        # ----------- PREDICTIONS ----------- #

        diabetes_prob = diabetes_model.predict_proba(diabetes_input)[0][1]
        heart_prob    = heart_model.predict_proba(heart_input)[0][1]
        liver_prob    = liver_model.predict_proba(liver_input)[0][1]
        kidney_prob   = kidney_model.predict_proba(kidney_input)[0][1]
        lung_prob     = lung_model.predict_proba(lung_input)[0][1]

        # ----------- FORMAT RESULTS ----------- #

        results = {
            "Diabetes":      round(diabetes_prob * 100, 2),
            "Heart Disease": round(heart_prob    * 100, 2),
            "Liver Disease": round(liver_prob    * 100, 2),
            "Kidney Disease":round(kidney_prob   * 100, 2),
            "Lung Disease":  round(lung_prob     * 100, 2),
        }

        highest = max(results, key=results.get)

        return render_template("result.html", results=results, highest=highest)

    except Exception as e:
        return f"<h2 style='font-family:sans-serif;padding:40px;color:#e8392a'>Error: {str(e)}</h2>"


if __name__ == "__main__":
    app.run(debug=True)
